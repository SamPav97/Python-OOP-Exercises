# from project.controller import Controller
#
#
# class CheckPlayer:
#     def check_player(self, name):
#         for player in Controller.players:
#             if player.name == name:
#                 return True
#         return False