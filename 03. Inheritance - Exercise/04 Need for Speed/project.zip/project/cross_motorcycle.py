from project.motorcycle import Motorcycle


class CrossMotorcycle(Motorcycle):
    def __init__(self, fuel, horsepower):
        super().__init__(fuel, horsepower)